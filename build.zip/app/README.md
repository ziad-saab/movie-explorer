movie-explorer
==============

Small webapp I created for the FOXHACK FirefoxOS hackathon
